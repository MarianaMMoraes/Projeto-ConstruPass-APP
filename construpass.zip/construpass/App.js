import * as React from 'react';
import {StyleSheet, View, Text, Image, ScrollView, Button,  } from 'react-native';
import { TextInput } from 'react-native-paper';

export default function 
App() 
{
 return (
<View style ={estilo.container}>

  <ScrollView>
  <Text style={estilo.titulo}> ConstruPass </Text>
  <View >
    <Image style={estilo.imagem} source={require("./assets/logo.jpg")}/>
    </View >
    <View >
    <Text style={estilo.login}> E-Mail </Text>
      <TextInput /**style={estilo.borda}**/  textContentType = 'emailAddress' label='Inserir E-mail'/>
     <Text style={estilo.login}> Senha </Text>
      <TextInput  textContentType = 'Password' label='Inserir Senha'/>
    </View >

<View style={estilo.fixToText}>
    <Button title = "Login" color = "#D96704" mode="contained" onPress={() => console.log('Pressed')}></Button>
</View>
<View>
<Text> </Text>
</View>
<View style={estilo.fixToText}>
    <Button title = "Ainda Não Sou Cliente" color = "#D96704" mode="contained" onPress={() => console.log('Pressed')}> </Button>
</View>
 <View >
    <Text style={estilo.titulo}> Sobre Nós </Text>
     
    </View >
    <Text style={estilo.texto}>A ConstruPass é uma plataforma que uni prestadores de serviço, com pessoas que demandam desses serviços .</Text>
</ScrollView>
    <Text style={estilo.legenda}>Acesse nosso Instagram @ConstruPass</Text>
</View>
 ) 
}

const estilo = StyleSheet.create(
  {
  container:
    {
      paddingtop: 700,
      flex:1,
      backgroundColor: "#303030",
      justifyContent: "center",
      alignItems: "center",
    },
    titulo:
    {
      fontSize: 30,
      color: '#D96704',
      FontWeight: "bold",
      marginTop: 30,
      textAlign: "center",
      paddingBottom: 10,
      borderRadius: 30,
    },
    imagem:
    {
    marginTop: 30,
    alignSelf: "center",
    marginBottom: 30,
    width: 150,
    height: 150,
    borderRadius: 105,
    },
    legenda:
    {
      fontSize: 18,
      textAlign: "center",
      FontWeight: "bold",
      paddingBottom: 20,
      padding: 20,
      paddingTop: 20,
      color: '#737373',

    },
    login:
    {
      fontSize: 18,
      FontWeight: "bold",
      paddingBottom: 20,
      paddingTop: 20,
      color: 'white',

    },
    texto:
    {
     textAlign: "justify",
      fontSize: 20,
      FontWeight: "bold",
      paddingLeft: 50,
      paddingRight: 50,
      paddingBottom: 20,
      paddingTop: 20,
      color: 'white',
    },
    fixToText: {
      flex: 1,
      height: 60,
    flexDirection: 'column',
    justifyContent: 'space-between',
  },
  //borda:{
   // underlineColorAndroid:'blue',
  //}
  }
)
